using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class LocationTrackingUI : MonoBehaviour
{
    public TextMeshProUGUI label;
    public TextMeshProUGUI distanceLabel;
}
